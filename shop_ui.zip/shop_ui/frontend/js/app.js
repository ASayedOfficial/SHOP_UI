// ================= IMPORT PRODUCTS =================
import { products } from './products.js';

// ================= SELECT MAIN ELEMENTS =================
const container = document.getElementById('productContainer');
const searchInput = document.querySelector('.search-container input');
const categoryButtons = document.querySelectorAll('.category-btn');

// ================= SELECT MODAL ELEMENTS =================
const modal = document.getElementById('productModal');
const closeModal = document.getElementById('closeModal');
const modalImage = document.getElementById('modalImage');
const modalName = document.getElementById('modalName');
const modalDetails = document.getElementById('modalDetails');

// ================= CART ELEMENTS =================
const cartIcon = document.getElementById("cartIcon");
const cartSidebar = document.getElementById("cartSidebar");
const overlay = document.getElementById("overlay");
const closeCart = document.getElementById("closeCart");
const cartCount = document.getElementById("cartCount");
const cartItemsContainer = document.getElementById("cartItems");
const cartTotal = document.getElementById("cartTotal");
const checkoutBtn = document.getElementById("checkoutBtn");

// ================= RECEIPT MODAL ELEMENTS =================
const receiptModal = document.getElementById("receiptModal");
const closeReceipt = document.getElementById("closeReceipt");
const paymentButtons = document.querySelectorAll(".payment-btn");

// ================= CART DATA =================
let cart = [];

// ================= HELPER FUNCTION =================
function getProductImages(product) {
    if (product.images && product.images.length > 0) {
        return product.images;
    }
    return [product.image];
}

// ================= RENDER PRODUCTS =================
function renderProducts(productList) {

    container.innerHTML = '';

    productList.forEach(product => {

        const productImages = getProductImages(product);

        const card = document.createElement('div');
        card.classList.add('product-card');

        card.innerHTML = `
            <img src="${productImages[0]}" class="product-img" alt="${product.name}" />
            <h3>${product.name}</h3>
            <p>$${product.price}</p>
            <button class="add-btn">Add to Cart</button>
        `;

        // ================= ADD TO CART =================
        const button = card.querySelector('.add-btn');
        button.addEventListener('click', () => addToCart(product.id));

        // ================= OPEN MODAL =================
        const image = card.querySelector('.product-img');
        image.addEventListener('click', () => {

            modal.style.display = "flex";
            modalImage.src = productImages[0];
            modalName.textContent = product.name;

            let thumbnailsHTML = '';

            if (productImages.length > 1) {
                thumbnailsHTML = `
                    <div class="thumbnail-container">
                        ${productImages.map(img => 
                            `<img src="${img}" class="thumb-img">`
                        ).join("")}
                    </div>
                `;
            }

            modalDetails.innerHTML = `
                ${thumbnailsHTML}
                <p><strong>Price:</strong> $${product.price}</p>
                <p><strong>Category:</strong> ${product.category}</p>
                <p>${product.description || ""}</p>
            `;

            const thumbImages = document.querySelectorAll('.thumb-img');

            if (thumbImages.length > 0) {
                thumbImages[0].classList.add('active-thumb');
            }

            thumbImages.forEach(thumb => {
                thumb.addEventListener('click', () => {
                    modalImage.src = thumb.src;
                    thumbImages.forEach(img => img.classList.remove('active-thumb'));
                    thumb.classList.add('active-thumb');
                });
            });

        });

        container.appendChild(card);
    });
}

// ================= ADD TO CART =================
function addToCart(id) {

    const product = products.find(p => p.id === id);

    const existingItem = cart.find(item => item.id === id);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            quantity: 1
        });
    }

    updateCartUI();
}

// ================= UPDATE CART UI =================
function updateCartUI() {

    cartItemsContainer.innerHTML = "";

    let total = 0;
    let totalItems = 0;

    cart.forEach(item => {

        total += item.price * item.quantity;
        totalItems += item.quantity;

        const cartItemHTML = `
            <div class="cart-item">
                <div>
                    <strong>${item.name}</strong>
                    <p>$${item.price} × ${item.quantity}</p>
                </div>
                <div>
                    $${item.price * item.quantity}
                </div>
            </div>
        `;

        cartItemsContainer.innerHTML += cartItemHTML;
    });

    cartCount.textContent = totalItems;
    cartTotal.textContent = "Total: $" + total;
}

// ================= CART SIDEBAR TOGGLE =================
cartIcon.addEventListener("click", () => {
    cartSidebar.classList.add("active");
    overlay.classList.add("active");
});

closeCart.addEventListener("click", () => {
    cartSidebar.classList.remove("active");
    overlay.classList.remove("active");
});

overlay.addEventListener("click", () => {
    cartSidebar.classList.remove("active");
    overlay.classList.remove("active");
});

// ================= CHECKOUT WITH RECEIPT =================
checkoutBtn.addEventListener("click", () => {

    if(cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    // Close cart sidebar
    cartSidebar.classList.remove("active");
    overlay.classList.remove("active");

    // Open receipt modal
    receiptModal.classList.add("active");
});

// Close receipt modal
closeReceipt.addEventListener("click", () => {
    receiptModal.classList.remove("active");
});

// Handle payment selection
paymentButtons.forEach(btn => {
    btn.addEventListener("click", () => {

        const method = btn.dataset.method;
        let totalAmount = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

        alert(`Payment Method: ${method}\nTotal Paid: $${totalAmount}\n\nThanks for your purchase!`);

        // Clear cart
        cart = [];
        updateCartUI();

        // Close receipt modal
        receiptModal.classList.remove("active");
    });
});

// ================= SEARCH FUNCTION =================
searchInput.addEventListener('input', () => {

    const query = searchInput.value.toLowerCase();

    const filteredProducts = products.filter(product =>
        product.name.toLowerCase().includes(query)
    );

    renderProducts(filteredProducts);
});

// ================= CATEGORY FILTER =================
categoryButtons.forEach(button => {

    button.addEventListener('click', () => {

        categoryButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');

        const category = button.dataset.category;

        if (category === "All") {
            renderProducts(products);
        } else {
            const filtered = products.filter(product =>
                product.category === category
            );
            renderProducts(filtered);
        }
    });
});

// ================= CLOSE MODAL =================
closeModal.addEventListener('click', () => {
    modal.style.display = "none";
});

window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = "none";
    }
});

// ================= INITIALIZE =================
renderProducts(products);