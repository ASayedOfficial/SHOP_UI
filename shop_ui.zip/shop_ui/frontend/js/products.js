// ================= Product List =================
// Add/Edit products here. Each product has:
// id - unique identifier
// name - product name
// price - product price in dollars
// image - path to local image in "images/" folder
// category - product category for filtering

export const products = [
    //Product 1
    { id: 1,
    //name of the product:1
    name: "Wireless Headphones", 
    //price of the product:1
    price: 300, 
    //images of the product:1
    images: [
            "images/Wireless Headphones.jpeg",
            "images/Wireless Headphones(1).jpeg",       
            "images/Wireless Headphones(2).jpeg"
        ], 
    //category of the product:1
    category: "Electronics"
    ,
        description: "High quality wireless headphones with deep bass and noise cancellation."
        ,details: "Experience the freedom of wireless music with our top-of-the-line headphones. Featuring advanced noise cancellation technology, these headphones deliver crystal clear sound and deep bass for an immersive listening experience. With a comfortable over-ear design and long battery life, you can enjoy your favorite tunes all day long without interruption."
        , brand: "Sony",
        stock: 15,
        rating: 4.5
    },
    //Product 2
    { id: 2, name: "Smart Watch", price: 40,
        images: [
            "images/Smart Watch.jpeg",
            "images/Smart Watch(1).jpeg",       
            "images/Smart Watch(2).jpeg"
        ]
        , category: "Electronics"
        ,
        description: "A sleek smartwatch with health tracking and notifications."
        ,details: "Stay connected and monitor your health with our premium smartwatch. It features a vibrant display, heart rate monitoring, step counting, and seamless integration with your smartphone for notifications and calls."
        , brand: "Apple",
        stock: 25,
        rating: 4.2
    },
    //Product 3
    { id: 3, name: "LED Lights", price: 10,
        //images of the product:3
        images: [
            "images/LED Lights.jpeg",
            "images/LED Lights(1).jpeg",       
            "images/LED Lights(2).jpeg"
        ], category: "Home"
        ,
        description: "Energy-efficient LED lights for any room."
        ,details: "Brighten up your space with our energy-efficient LED lights. These lights are designed to last longer than traditional bulbs and consume less energy, making them an eco-friendly choice for any home."
        , brand: "Philips",
        stock: 30,
        rating: 4.0
    },
    //Product 4
    { id: 4, name: "Perfume", price: 120, 
        //images of the product:4
        images: [
            "images/Perfume.jpeg",
            "images/Perfume(1).jpeg",       
            "images/Perfume(2).jpeg"
        ], 
        category: "Beauty" 
        ,
        description: "A luxurious perfume with a long-lasting scent."
        ,details: "Indulge in the captivating aroma of our luxurious perfume. Crafted with a blend of exquisite notes, this fragrance offers a long-lasting scent that will leave you feeling confident and elegant throughout the day."
        , brand: "Dior",
        stock: 20,
        rating: 4.7
    },
    //Product 5
    { id: 5, name: "Body Spray", price: 80,
        //images of the product:5
        images: [
            "images/Body Spray.jpeg",
            "images/Body Spray(1).jpeg",       
            "images/Body Spray(2).jpeg"
        ],  
        category: "Beauty"
        ,
        description: "A refreshing body spray with a light floral scent."
        ,details: "Refresh your senses with our invigorating body spray. This light and floral fragrance is perfect for daily use, leaving you feeling clean and confident throughout the day."
        , brand: "L'Oréal",
        stock: 25,
        rating: 4.3
    },
    //Product 6
    { id: 6, name: "Earbuds", price: 90, 
        //images of the product:6
        images: [
            "images/Earbuds.jpeg",
            "images/Earbuds(1).jpeg",       
            "images/Earbuds(2).jpeg"
        ], category: "Electronics" 
        ,
        description: "Compact earbuds with excellent sound quality."
        ,details: "Enjoy your music on the go with our compact earbuds. Featuring superior sound quality and a comfortable fit, these earbuds are perfect for workouts, commutes, or just relaxing at home."
        , brand: "Samsung",
        stock: 30,
        rating: 4.5
    },
    //Product 7
    { id: 7, name: "Hair Dryer", price: 600, 
        //images of the product:7
        images: [
            "images/Hair Dryer.jpeg",
            "images/Hair Dryer(1).jpeg",       
            "images/Hair Dryer(2).jpeg"
        ], category: "Beauty" 
        ,
        description: "A powerful hair dryer with multiple heat settings."
        ,details: "Achieve salon-quality results at home with our powerful hair dryer. It features multiple heat and speed settings, as well as a cool shot button to help set your style in place."
        , brand: "Revlon",
        stock: 20,
        rating: 4.4
    },
    //Product 8
    { id: 8, name: "Camera", price: 600, 
        images: [
            "images/Camera.jpeg",
            "images/Camera(1).jpeg",       
            "images/Camera(2).jpeg"
        ], category: "Electronics" 
        ,
        description: "High-performance camera for professional photography."
        ,details: "Capture stunning photos with our high-performance camera. Featuring advanced technology and a sleek design, this camera is perfect for both amateur and professional photographers."
        , brand: "Canon",
        stock: 15,
        rating: 4.6
    },
    //Product 9
    { id: 9, name: "Cooling Fan", price: 600, 
        images: [
            "images/Cooling Fan.jpeg",
            "images/Cooling Fan(1).jpeg",       
            "images/Cooling Fan(2).jpeg"
        ], category: "Home" 
        ,
        description: "A beautiful cooling fan to keep your home comfortable."
        ,details: "Stay cool and comfortable in your home with our high-quality cooling fan. Featuring a sleek design and powerful airflow, this fan is perfect for any room in your house."
        , brand: "Artisan",
        stock: 10,
        rating: 4.8
    },
    //Product 10
    { id: 10, name: "Bluetooth Speaker", price: 200, 
        images: [
            "images/Bluetooth Speaker.jpeg",
            "images/Bluetooth Speaker(1).jpeg",       
            "images/Bluetooth Speaker(2).jpeg"
        ], category: "Electronics" 
        ,
        description: "A portable Bluetooth speaker with high-quality sound."
        ,details: "Enjoy crystal-clear sound anywhere with our portable Bluetooth speaker. Featuring advanced audio technology and a compact design, this speaker is perfect for outdoor adventures, home parties, or relaxing at home."
        , brand: "JBL",
        stock: 25,
        rating: 4.6
    }
];