const Product = require("../models/Product");

// GET all products
exports.getProducts = async (req, res) => {
    const products = await Product.find();
    res.json(products);
};

// CREATE product
exports.createProduct = async (req, res) => {
    const { name, price, description, image } = req.body;

    const product = await Product.create({
    name,
    price,
    description,
    image
    });

    res.status(201).json(product);
};